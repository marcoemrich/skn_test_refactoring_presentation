class Factories {
	public final static String defaultName = "Object Oriented Programming";
	public final static float defaultNetPrice = 500;
	public final static boolean defaultTaxFree = true;
	
	public static Seminar createTaxFreeSeminar() {
		return new Seminar(defaultName, defaultNetPrice, true);
	} 
	public static Seminar createNotTaxFreeSeminar() {
		return new Seminar(defaultName, defaultNetPrice, false);
	} 

	public static Seminar createSeminarWithName(String name) {
		return new Seminar(name, defaultNetPrice, defaultTaxFree);
	} 
	
	// weitere Mother-Methoden
}