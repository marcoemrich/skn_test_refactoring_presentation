import static org.junit.Assert.*;

import org.junit.Test;

public class SeminarTaxTest {
	// ... 2 weitere Testmethoden

	@Test
	public void testANotTaxFreeSeminarShouldHaveTheCorrectTaxRate() {
		Seminar seminar = Factories.createNotTaxFreeSeminar();
		assertEquals(Seminar.TAX_RATE, seminar.taxRate(), 0.001);
	}	
}