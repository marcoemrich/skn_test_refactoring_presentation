public class Seminar {
	
	public final static float TAX_RATE = (float) 1.19;
	public final static int THREE_LETTER_DISCOUNT_RATE = 5;
	
	public Seminar(String name, float netPrice, boolean taxFree) {
		this.name     = name;
		this.netPrice = netPrice;
		this.taxFree  = taxFree;
	}

	public void setNetPrice(float netPrice) {
		this.netPrice = netPrice;
	}

	public void setTaxFree(boolean taxFree) {
		this.taxFree = taxFree;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public float grossPrice() {
		return netPrice() * taxRate();
	}
	
	public float netPrice() {
		return netPrice - discount();
	}
	
	public float taxRate() {
		return taxFree ? 1 : TAX_RATE / 100;		
	}
	
	public float discount() {
		return netPrice * discountRate() / 100;
	}
	
	public float discountRate() {
		return isThreeLetterDiscountGranted() ? THREE_LETTER_DISCOUNT_RATE : 0;
	}
	
	public boolean isThreeLetterDiscountGranted() {
		return name.length() < 3;
	}

	private float netPrice;
	private boolean taxFree;
	private String name;
}
