import static org.junit.Assert.*;

import org.junit.Test;

public class SeminarDiscountTest {
	// ... 5 weitere Testmethoden
	
	@Test
	public void testIsThreeLetterDiscountGrantedShouldReturnTrueIfNameConsistOf3Letters() {
		Seminar seminar = Factories.createSeminarWithName("OOP");
		assertTrue(seminar.isThreeLetterDiscountGranted());
	}

}
