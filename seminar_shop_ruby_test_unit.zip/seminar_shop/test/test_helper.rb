require File.expand_path('../../seminar', __FILE__)
require "test/unit"
require "mocha"