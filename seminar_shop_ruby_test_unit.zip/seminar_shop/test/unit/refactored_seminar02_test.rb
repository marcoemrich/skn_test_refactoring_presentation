require '../test_helper'

class SeminarTest < Test::Unit::TestCase

  # Split test cases, AAA-Pattern & Fresh Fixture
  # Arrange, Act, Assert

  def test_a_tax_free_seminar_should_return_a_gross_price_without_tax
    seminar = Seminar.new('Objekt-Orientierte Programmierung', 500, true)
    assert_equal 500, seminar.gross_price
  end

  def test_a_3letter_seminar_should_return_a_gross_price_with_discount
    seminar = Seminar.new('OOP', 500, true)
    assert_equal 475, seminar.gross_price
  end

  def test_a_not_tax_free_seminar_should_return_gross_price_with_correct_tax
    seminar = Seminar.new('Objekt-Orientierte Programmierung', 500, false)
    assert_equal 595, seminar.gross_price
  end

end
