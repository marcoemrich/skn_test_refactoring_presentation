require '../test_helper'

# isolate

module Factories
  def create_seminar(args = {})
    new_args = {
        :name => 'Object Oriented Programming',
        :net_price => 500,
        :tax_free => true
    }.merge(args)

    Seminar.new(new_args[:name], new_args[:net_price], new_args[:tax_free])
  end

end

class SeminarTaxTest < Test::Unit::TestCase
  include Factories

  def test_a_tax_free_seminar_should_return_a_gross_price_without_tax
    seminar = create_seminar(tax_free: true)
    assert_equal seminar.net_price, seminar.gross_price
  end

  def test_a_not_tax_free_seminar_should_return_gross_price_with_correct_tax
    seminar = create_seminar(tax_free: false)
    assert_equal seminar.net_price * Seminar::TAX_RATE, seminar.gross_price
  end

end

class SeminarDiscountTest < Test::Unit::TestCase
  include Factories

  def test_a_3letter_seminar_should_return_a_gross_price_with_discount
    seminar = create_seminar(name: 'OOP', net_price: 500)
    assert_equal 500 * 0.95, seminar.net_price
  end

  def test_a_more_than_3letters_seminar_should_return_a_net_price_without_discount
    seminar = create_seminar(name: 'Object Oriented Programming', net_price: 500)
    assert_equal 500, seminar.net_price
  end

end