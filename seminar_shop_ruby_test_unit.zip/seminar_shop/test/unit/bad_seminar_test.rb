require '../test_helper'

class SeminarTest < Test::Unit::TestCase

  def test_seminar_should_calculate_correct_gross_prices
    seminar = Seminar.new('OOP', 500, false)
    
    assert_equal 565.25, seminar.gross_price # <== Failure

    seminar.net_price = 300
    assert_equal 339.15, seminar.gross_price

    seminar.tax_free = true
    assert_equal 285, seminar.gross_price

    seminar.name = 'Objekt-Orientierte Programmierung'
    assert_equal 300, seminar.gross_price
  end

end

# Failure:
# <565.25> expected but was
# <5.95>.
