require '../test_helper'

# isolate, use mock and stubs where necessary

module Factories
  def create_seminar(args = {})
    new_args = {
        :name => 'Object Oriented Programming',
        :net_price => 500,
        :tax_free => true
    }.merge(args)

    Seminar.new(new_args[:name], new_args[:net_price], new_args[:tax_free])
  end

end

class SeminarTaxTest < Test::Unit::TestCase
  include Factories

  def test_a_tax_free_seminar_should_have_a_tax_rate_of_1
    seminar = create_seminar(tax_free: true)
    assert_equal 1, seminar.tax_rate
  end

  def test_a_not_tax_free_seminar_should_have_the_correct_tax_rate
    seminar = create_seminar(tax_free: false)
    assert_equal Seminar::TAX_RATE, seminar.tax_rate
  end

  def test_seminar_should_use_tax_rate_to_calculate_gross_price
    seminar = create_seminar(tax_free: false)
    seminar.stubs(:net_price => 100)
    seminar.stubs(:tax_rate => 1.5)
    assert_equal 150, seminar.gross_price
  end

end

class SeminarDiscountTest < Test::Unit::TestCase
  include Factories

  def test_a_seminar_consisting_of_3_letters_should_return_a_net_price_with_3letter_discount_of_5_percent
    seminar = create_seminar(name: 'OOP', net_price: 500)
    assert_equal 500 * 0.95, seminar.net_price
  end

  def test_a_seminar_consisting_of_more_than_3_letters_should_return_a_net_price_without_discount
    seminar = create_seminar(name: 'Object Oriented Programming', net_price: 500)
    assert_equal 500, seminar.net_price
  end
  
end
