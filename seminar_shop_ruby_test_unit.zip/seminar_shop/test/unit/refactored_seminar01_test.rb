require '../test_helper'

class RefactoredSeminar01Test < Test::Unit::TestCase

  # use neutral start fixture
  # use up-building-direction

  def test_seminar_should_calculate_correct_gross_prices
    seminar = Seminar.new('Objekt-Orientierte Programmierung', 500, true)

    assert_equal 500, seminar.gross_price

    seminar.name = 'OOP'
    assert_equal 475, seminar.gross_price

    seminar.tax_free = false
    assert_equal 565.25, seminar.gross_price
  end

end
