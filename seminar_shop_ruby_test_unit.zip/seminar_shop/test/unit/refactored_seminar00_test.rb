require '../test_helper'

class SeminarTest < Test::Unit::TestCase

  # remove redundant tests

  def test_seminar_should_calculate_correct_gross_prices
    seminar = Seminar.new('OOP', 500, false)
    
    assert_equal 565.25, seminar.gross_price

    seminar.tax_free = true
    assert_equal 475, seminar.gross_price

    seminar.name = 'Objekt-Orientierte Programmierung'
    assert_equal 500, seminar.gross_price
  end

end
