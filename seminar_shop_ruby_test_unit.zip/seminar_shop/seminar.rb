class Seminar
  TAX_RATE = 1.19
  THREE_LETTER_DISCOUNT_RATE = 5

  attr_writer :net_price, :tax_free, :name

  def initialize(name, net_price, tax_free)
    @name, @net_price, @tax_free = name, net_price, tax_free
  end

  def gross_price
    net_price * tax_rate #* 10
  end

  def net_price
    @net_price - discount
  end

  def tax_rate
    @tax_free ? 1 : TAX_RATE #/ 100
  end

  def discount
    @net_price * discount_rate / 100
  end

  def discount_rate
    three_letter_discount_granted? ? THREE_LETTER_DISCOUNT_RATE : 0
  end

  def three_letter_discount_granted?
    @name.size <= 3 # <=3
  end

end